import psutil

def get_network_io():
    try:
        net_io = psutil.net_io_counters()
        return {
            'bytes_sent': net_io.bytes_sent,
            'bytes_recv': net_io.bytes_recv
        }
    except Exception as e:
        print(f"Error fetching network I/O: {e}")
        return {'bytes_sent': 0, 'bytes_recv': 0}
