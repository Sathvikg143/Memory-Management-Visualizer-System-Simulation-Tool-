import psutil

def get_cpu_usage():
    try:
        return {
            'used': psutil.cpu_percent(interval=1)
        }
    except Exception as e:
        print(f"Error fetching CPU usage: {e}")
        return {'used': 0}
