import psutil

def get_disk_usage():
    try:
        disk_usage = psutil.disk_usage('/')
        return {
            'used': disk_usage.percent,
            'free': 100 - disk_usage.percent
        }
    except Exception as e:
        print(f"Error fetching disk usage: {e}")
        return {'used': 0, 'free': 0}
