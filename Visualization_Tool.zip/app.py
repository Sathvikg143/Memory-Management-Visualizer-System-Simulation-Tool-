import dash
from dash import dcc, html, exceptions
from dash.dependencies import Input, Output, State
import plotly.graph_objects as go

# --- Import your monitoring and history functions ---
from monitor_disk import get_disk_usage
from monitor_network import get_network_io
from monitor_ram import get_ram_usage
from monitor_cpu import get_cpu_usage
from update_history import update_history, initialize_history

# --- Initialize Dash App ---
# By default, Dash will automatically look for an 'assets' folder
# and load any CSS files inside it.
app = dash.Dash(__name__, suppress_callback_exceptions=True)
app.title = "System Visualizer"

# --- Initialize data storage by loading from CSV ---
history = initialize_history()

# =============================================================================
# STYLES - For Inline Component Styling
# =============================================================================
NAV_HEIGHT = '80px'
NAV_STYLE = {
    'display': 'flex',
    'justifyContent': 'space-between',
    'alignItems': 'center',
    'padding': '1rem 2rem',
    'backgroundColor': 'rgba(13, 17, 23, 0.8)',
    'backdropFilter': 'blur(10px)',
    'color': 'white',
    'position': 'fixed',
    'width': '100%',
    'top': '0',
    'left': '0',
    'zIndex': '1000',
    'height': NAV_HEIGHT,
    'boxSizing': 'border-box'
}

# =============================================================================
# PAGE LAYOUTS
# =============================================================================

def create_landing_page():
    """Creates the layout for the impressive landing page."""
    return html.Div([
        # --- Starfield Background Container ---
        html.Div([
            html.Div(className='stars-small'),
            html.Div(className='stars-medium'),
            html.Div(className='stars-large'),
        ], className='starfield-container'),
        
        html.Header([
            html.H2("Memory Management Visualizer", style={'margin': '0', 'fontWeight': 'bold'}),
            html.Nav([
                
                dcc.Link("Dashboard", href='/dashboard', className='nav-button')
            ])
        ], style=NAV_STYLE),

        html.Main([
            html.Section([
                html.H1("Visualize Your System's Performance", className='hero-title'),
                html.P("A professional, lightweight dashboard to monitor your system resources with clarity and precision."),
                dcc.Link("LAUNCH DASHBOARD", href='/dashboard', className='launch-button')
            ], className='hero-section'),

            html.Section([
                html.H2("Key Features at a Glance"),
                html.Div([
                    html.Div([html.H1("📊"), html.H3("Real-Time Gauges"), html.P("Immediate feedback on CPU, RAM, and Disk usage.")], className='feature-card'),
                    html.Div([html.H1("📈"), html.H3("Historical Analysis"), html.P("Track performance trends to identify patterns.")], className='feature-card'),
                    html.Div([html.H1("🌐"), html.H3("Network Throughput"), html.P("Monitor total bytes sent and received.")], className='feature-card'),
                    html.Div([html.H1("🔔"), html.H3("Customizable Alerts"), html.P("Get notified when usage exceeds your thresholds.")], className='feature-card'),
                ], className='features-grid')
            ], className='content-section'),
            
            html.Section([
                html.H2("How It Works"),
                html.Div([
                    html.Div([html.Div("1", className='step-number'), html.H3("Launch"), html.P("Open the live dashboard to begin monitoring.")], className='step-card'),
                    html.Div([html.Div("2", className='step-number'), html.H3("Configure"), html.P("Set custom alert thresholds for CPU, RAM, and Disk.")], className='step-card'),
                    html.Div([html.Div("3", className='step-number'), html.H3("Monitor"), html.P("Watch your system's performance in real-time.")], className='step-card'),
                ], className='features-grid')
            ], className='content-section light-bg'),

            html.Section([
                html.H2("Built With a Modern Tech Stack"),
                html.Div([
                    html.Div([html.H3("Dash & Plotly"), html.P("For a fully interactive, web-based user interface.")], className='tech-card'),
                    html.Div([html.H3("Psutil"), html.P("The core library for accessing real-time system information.")], className='tech-card'),
                    html.Div([html.H3("Pandas"), html.P("For efficient data handling and historical logging.")], className='tech-card'),
                ], className='features-grid')
            ], className='content-section'),

            # --- Footer ---
            html.Footer([
                html.P("© 2025 System Monitor Dashboard | Project by [Sathvik Guptha A & Mahendra Babu T]")
            ])
        ], style={'paddingTop': NAV_HEIGHT})
    ])

def create_dashboard_layout():
    """Creates the layout for the monitoring dashboard page."""
    return html.Div([
        html.Header([
            html.H2("System Monitor Dashboard", style={'margin': '0'}),
            dcc.Link("Back to Home", href='/', style={'color': 'white', 'text-decoration': 'none'})
        ], style=NAV_STYLE),

        html.Main([
            html.Div([
                html.Div([
                    html.Div([
                        html.H4("Alert Thresholds", style={'marginTop': '0'}),
                        html.Div([
                            html.Label("CPU (%):", style={'display': 'block'}),
                            dcc.Input(id='cpu-threshold', type='number', value=80, style={'width': '100%'})
                        ], style={'marginBottom': '1rem'}),
                        html.Div([
                            html.Label("RAM (%):", style={'display': 'block'}),
                            dcc.Input(id='ram-threshold', type='number', value=80, style={'width': '100%'})
                        ], style={'marginBottom': '1rem'}),
                        html.Div([
                            html.Label("Disk (%):", style={'display': 'block'}),
                            dcc.Input(id='disk-threshold', type='number', value=80, style={'width': '100%'})
                        ]),
                    ], className='control-box'),
                    
                    html.Div([
                        html.H4("System Alerts", style={'marginTop': '0'}),
                        html.Div(id='alerts', children="All systems normal.")
                    ], className='control-box', style={'marginTop': '1rem'})
                ], style={'flex': '1 1 300px', 'margin': '1rem'}),

                html.Div([
                    html.Div([
                        dcc.Graph(id='cpu-usage', style={'minWidth': '0', 'flex': '1 1 30%'}),
                        dcc.Graph(id='ram-usage', style={'minWidth': '0', 'flex': '1 1 30%'}),
                        dcc.Graph(id='disk-usage', style={'minWidth': '0', 'flex': '1 1 30%'}),
                    ], style={'display': 'flex', 'flexWrap': 'wrap'}),
                    
                    html.Div([
                        dcc.Graph(id='historical-data'),
                        dcc.Graph(id='network-throughput'),
                    ])
                ], style={'flex': '3 1 700px', 'margin': '1rem'}),
            ], style={'display': 'flex', 'flexWrap': 'wrap'}),
        ], style={'paddingTop': NAV_HEIGHT, 'paddingLeft': '1rem', 'paddingRight': '1rem'})
    ])

# --- Main App Layout for URL Routing ---
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    dcc.Interval(
        id='update-interval',
        interval=2000,
        n_intervals=0,
        disabled=True # Start as disabled
    ),
    html.Div(id='page-container') # A single container for all page content
])

# =============================================================================
# CALLBACKS
# =============================================================================

@app.callback(
    [Output('page-container', 'children'),
     Output('update-interval', 'disabled')],
    [Input('url', 'pathname')]
)
def display_page_and_toggle_interval(pathname):
    """
    This single callback handles both rendering the correct page and
    enabling/disabling the interval timer.
    """
    if pathname == '/dashboard':
        return create_dashboard_layout(), False # Show dashboard, enable timer
    else:
        return create_landing_page(), True # Show landing, disable timer

@app.callback(
    [
        Output('cpu-usage', 'figure'),
        Output('ram-usage', 'figure'),
        Output('disk-usage', 'figure'),
        Output('network-throughput', 'figure'),
        Output('historical-data', 'figure'),
        Output('alerts', 'children')
    ],
    [Input('update-interval', 'n_intervals')],
    [
        State('cpu-threshold', 'value'),
        State('ram-threshold', 'value'),
        State('disk-threshold', 'value')
    ],
    prevent_initial_call=True
)
def update_dashboard(n, cpu_thresh, ram_thresh, disk_thresh):
    """Updates all graphs and alerts on the dashboard page."""
    cpu_info = get_cpu_usage()
    memory_info = get_ram_usage()
    disk_info = get_disk_usage()
    network_info = get_network_io()
    
    update_history(cpu_info, memory_info, disk_info, network_info)

    gauge_layout = {'margin': dict(l=20, r=20, t=40, b=20), 'paper_bgcolor': 'rgba(0,0,0,0)', 'font': {'color': '#EAEAEA'}}
    cpu_fig = go.Figure(go.Indicator(mode="gauge+number", value=cpu_info['used'], title={'text': "CPU Usage (%)"}, gauge={'axis': {'range': [0, 100]}}))
    cpu_fig.update_layout(gauge_layout)
    
    ram_fig = go.Figure(go.Indicator(mode="gauge+number", value=memory_info['used'], title={'text': "RAM Usage (%)"}, gauge={'axis': {'range': [0, 100]}}))
    ram_fig.update_layout(gauge_layout)

    disk_fig = go.Figure(go.Indicator(mode="gauge+number", value=disk_info['used'], title={'text': "Disk Usage (%)"}, gauge={'axis': {'range': [0, 100]}}))
    disk_fig.update_layout(gauge_layout)

    line_layout = {'margin': dict(l=40, r=20, t=40, b=40), 'paper_bgcolor': 'rgba(0,0,0,0)', 'plot_bgcolor': 'rgba(30, 36, 42, 0.8)', 'font': {'color': '#EAEAEA'}, 'legend': dict(x=0.01, y=0.99)}
    net_fig = go.Figure()
    net_fig.add_trace(go.Scatter(x=history['timestamp'], y=history['bytes_sent'], mode='lines', name='Bytes Sent'))
    net_fig.add_trace(go.Scatter(x=history['timestamp'], y=history['bytes_recv'], mode='lines', name='Bytes Received'))
    net_fig.update_layout(title="Network Throughput", xaxis_title="Time", yaxis_title="Bytes", **line_layout)

    hist_fig = go.Figure()
    hist_fig.add_trace(go.Scatter(x=history['timestamp'], y=history['used_cpu'], mode='lines', name='CPU Usage (%)'))
    hist_fig.add_trace(go.Scatter(x=history['timestamp'], y=history['used_ram'], mode='lines', name='RAM Usage (%)'))
    hist_fig.add_trace(go.Scatter(x=history['timestamp'], y=history['used_disk'], mode='lines', name='Disk Usage (%)'))
    hist_fig.update_layout(title="Historical Usage", xaxis_title="Time", yaxis_title="Usage (%)", **line_layout)
    
    alerts = []
    if cpu_info['used'] > cpu_thresh:
        alerts.append(html.P(f"🔥 CPU Alert: Usage is {cpu_info['used']}%", style={'color': '#FF4136', 'fontWeight': 'bold'}))
    if memory_info['used'] > ram_thresh:
        alerts.append(html.P(f"🔥 RAM Alert: Usage is {memory_info['used']}%", style={'color': '#FF4136', 'fontWeight': 'bold'}))
    if disk_info['used'] > disk_thresh:
        alerts.append(html.P(f"🔥 Disk Alert: Usage is {disk_info['used']}%", style={'color': '#FF4136', 'fontWeight': 'bold'}))
    
    alert_message = alerts if alerts else "All systems normal."
    
    return cpu_fig, ram_fig, disk_fig, net_fig, hist_fig, alert_message

# --- Run the App ---
if __name__ == '__main__':
    app.run(debug=True)
