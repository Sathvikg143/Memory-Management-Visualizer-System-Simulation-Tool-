import psutil

def get_ram_usage():
    try:
        memory_info = psutil.virtual_memory()
        return {
            'used': memory_info.percent,
            'free': 100 - memory_info.percent
        }
    except Exception as e:
        print(f"Error fetching RAM usage: {e}")
        return {'used': 0, 'free': 0}
