import pandas as pd
import datetime
import os

# Set a limit for the number of data points to keep in memory for plotting
MAX_HISTORY_POINTS = 100
HISTORY_FILE = 'system_monitoring_history.csv'

# This dictionary will hold the rolling window of data for the graphs
history = {
    'timestamp': [],
    'used_cpu': [],
    'used_ram': [],
    'free_ram': [],
    'used_disk': [],
    'free_disk': [],
    'bytes_sent': [],
    'bytes_recv': []
}

def initialize_history():
    """
    Initializes the history by loading the last MAX_HISTORY_POINTS
    from the CSV file if it exists.
    """
    global history
    if os.path.exists(HISTORY_FILE):
        df = pd.read_csv(HISTORY_FILE)
        # Get the last N rows from the dataframe
        history = df.tail(MAX_HISTORY_POINTS).to_dict('list')
    return history

def update_history(cpu_info, memory_info, disk_info, network_info):
    """
    Appends the new data to the in-memory history, trims it to a fixed size,
    and appends the new data to the CSV file efficiently.
    """
    global history
    
    current_time = datetime.datetime.now()
    
    # Create a dictionary for the new data row
    new_data = {
        'timestamp': current_time,
        'used_cpu': cpu_info['used'],
        'used_ram': memory_info['used'],
        'free_ram': memory_info.get('free', 100 - memory_info['used']),
        'used_disk': disk_info['used'],
        'free_disk': disk_info.get('free', 100 - disk_info['used']),
        'bytes_sent': network_info['bytes_sent'],
        'bytes_recv': network_info['bytes_recv']
    }

    # Append new data to the in-memory history for plotting
    for key, value in new_data.items():
        history[key].append(value)
        # Trim the list to keep only the last MAX_HISTORY_POINTS
        history[key] = history[key][-MAX_HISTORY_POINTS:]

    # Save only the new data to the CSV
    try:
        # Create a DataFrame with just the new row
        df_new = pd.DataFrame([new_data])
        # Append to the CSV file without writing the header if the file already exists
        df_new.to_csv(HISTORY_FILE, mode='a', header=not os.path.exists(HISTORY_FILE), index=False)
    except Exception as e:
        print(f"Error updating history file: {e}")